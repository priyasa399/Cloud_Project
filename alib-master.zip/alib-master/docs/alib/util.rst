``alib.util``
=============

.. automodule:: alib.util
  :members:
  :undoc-members: