``alib.mip``
============

.. automodule:: alib.mip
  :members:
  :undoc-members: