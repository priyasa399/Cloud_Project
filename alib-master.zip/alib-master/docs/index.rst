Welcome to alib's documentation!
================================



.. toctree::
  :maxdepth: 1

  alib/datamodel
  alib/evaluation
  alib/mip
  alib/modelcreator
  alib/run_experiment
  alib/scenariogeneration
  alib/solutions
  alib/suitable_substrates
  alib/test_utils
  alib/util

.. only:: builder_html

  Indices and tables
  ------------------

  * :ref:`genindex`
  * :ref:`modindex`
  * :ref:`search`
