# License

This data is extracted from [The Internet Topology Zoo](http://www.topology-zoo.org/).

Authors of the original data: Knight, S. and Nguyen, H.X. and Falkner, N. and Bowden, R. and Roughan, M.
